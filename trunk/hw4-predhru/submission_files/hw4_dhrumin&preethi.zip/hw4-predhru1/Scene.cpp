#include "Scene.h"
#include "Image.h"
#include<stdio.h>

CameraRay::CameraRay()
	{
		u = vec3(0,0,0);
		w = vec3(0,0,0);
		v = vec3(0,0,0);
		fov = 0.0;
	}
CameraRay::CameraRay(vec3 _eye, vec3 _center, vec3 _up, float _fov)
	{
		eye = _eye;
		up = _up;
		center = _center;
		w = eye - center;
		printf("w is : %f %f %f\n",w.x,w.y,w.z);
		w.normalize();
		u = cross(u,up,w);
		u.normalize();
		printf("u is : %f %f %f\n",u.x,u.y,u.z);
		v = cross(v,w,u);
		printf("v is : %f %f %f\n",v.x,v.y,v.z);
		fov = _fov;
		printf("eye is : %f %f %f\n",eye.x,eye.y,eye.z);
	}
CameraRay camera;

Ray::Ray()
{
	begin = vec3(0,0,0);
	end = vec3(0,0,0);
}

bool Scene::intersect_quadrilateral_ray( Quadrilateral& q,Ray& r, float& u, float& v, float& t)
{
  static float eps = float(10e-6);

  // Rejects rays that are parallel to Q, and rays that intersect the plane of
  // Q either on the left of the line V00V01 or on the right of the line V00V10.

  vec3 E_01 = q.v_10() - q.v_00();
  vec3 E_03 = q.v_01() - q.v_00();
  vec3 P = cross(P,r.end, E_03);
  float det = dot(det,E_01, P);
  if (std::abs(det) < eps) return false;
  float inv_det = float(1.0) / det;
  vec3 T = r.begin - q.v_00();
  float alpha = dot(alpha,T, P) * inv_det;
  if (alpha < float(0.0)) return false;
  // if (alpha > float(1.0)) return false; // Uncomment if VR is used.
  vec3 Q = cross(Q,T, E_01);
  float beta = dot(beta,r.end, Q) * inv_det;
  if (beta < float(0.0)) return false; 
  // if (beta > float(1.0)) return false; // Uncomment if VR is used.

  if ((alpha + beta) > float(1.0)) {

    // Rejects rays that intersect the plane of Q either on the
    // left of the line V11V10 or on the right of the line V11V01.

    vec3 E_23 = q.v_01() - q.v_11();
    vec3 E_21 = q.v_10() - q.v_11();
    vec3 P_prime = cross(P_prime,r.end, E_21);
    float det_prime = dot(det_prime,E_23, P_prime);
    if (std::abs(det_prime) < eps) return false;
    float inv_det_prime = float(1.0) / det_prime;
	vec3 T_prime = r.begin - q.v_11();
    float alpha_prime = dot(alpha_prime,T_prime, P_prime) * inv_det_prime;
    if (alpha_prime < float(0.0)) return false;
    vec3 Q_prime = cross(Q_prime,T_prime, E_23);
	float beta_prime = dot(beta_prime,r.end, Q_prime) * inv_det_prime;
    if (beta_prime < float(0.0)) return false;
  }

  // Compute the ray parameter of the intersection point, and
  // reject the ray if it does not hit Q.

  t = dot(t,E_03, Q) * inv_det;
  if (t < float(0.0)) return false; 

  // Compute the barycentric coordinates of the fourth vertex.
  // These do not depend on the ray, and can be precomputed
  // and stored with the quadrilateral.  

  float alpha_11, beta_11;
  vec3 E_02 = q.v_11() - q.v_00();
  vec3 n = cross(n,E_01, E_03);

  if ((std::abs(n.x) >= std::abs(n.y))
    && (std::abs(n.x) >= std::abs(n.z))) {

    alpha_11 = ((E_02.y * E_03.z) - (E_02.z * E_03.y)) / n.x;
    beta_11  = ((E_01.y * E_02.z) - (E_01.z * E_02.y)) / n.x;
  }
  else if ((std::abs(n.y) >= std::abs(n.x))
    && (std::abs(n.y) >= std::abs(n.z))) {  

    alpha_11 = ((E_02.z * E_03.x) - (E_02.x * E_03.z)) / n.y;
    beta_11  = ((E_01.z * E_02.x) - (E_01.x * E_02.z)) / n.y;
  }
  else {

    alpha_11 = ((E_02.x * E_03.y) - (E_02.y * E_03.x)) / n.z;
    beta_11  = ((E_01.x * E_02.y) - (E_01.y * E_02.x)) / n.z;
  }

  // Compute the bilinear coordinates of the intersection point.

  if (std::abs(alpha_11 - float(1.0)) < eps) {    

    // Q is a trapezium.
    u = alpha;
    if (std::abs(beta_11 - float(1.0)) < eps) v = beta; // Q is a parallelogram.
    else v = beta / ((u * (beta_11 - float(1.0))) + float(1.0)); // Q is a trapezium.
  }
  else if (std::abs(beta_11 - float(1.0)) < eps) {

    // Q is a trapezium.
    v = beta;
    u = alpha / ((v * (alpha_11 - float(1.0))) + float(1.0));
  }
  else {

    float A = float(1.0) - beta_11;
    float B = (alpha * (beta_11 - float(1.0)))
      - (beta * (alpha_11 - float(1.0))) - float(1.0);
    float C = alpha;
    float D = (B * B) - (float(4.0) * A * C);
    float Q = float(-0.5) * (B + ((B < float(0.0) ? float(-1.0) : float(1.0))
      * std::sqrt(D)));
    u = Q / A;
    if ((u < float(0.0)) || (u > float(1.0))) u = C / Q;
    v = beta / ((u * (beta_11 - float(1.0))) + float(1.0)); 
  }

  return true;
}

void Scene::generateRays(CameraRay *camera)
{
	vec3 pt;
	ray.begin = camera->eye;
	printf("eye is %f, %f, %f\n", camera->eye.x, camera->eye.y, camera->eye.z); 
	 
	vec3 v1 = vec3(-1,-1,0);
	vec3 v2 = vec3(1,-1,0);
	vec3 v3 = vec3(1,1,0);
	vec3 v4 = vec3(-1,1,0);
	Quadrilateral q(v1,v2,v3,v4);	
	float u,v,t;
	Image img;
	img.setSize();
	//float remainingtime = 0;
	//float totaltime = I->getHeight() + I->getWidth();
	//float percentremaining;
	for(int i=0; i<HEIGHT; i++)
	{
		printf("\nRow %d\n", i);
		for(int j=0; j<WIDTH; j++)
		{
			vec3 color(0.0, 0.0, 0.0);
			ray.end = camera->calcRays(i,j);
			//color = getRayIntersection(&myR, RECURSION_DEPTH, false);
			if(intersect_quadrilateral_ray(q,ray,u,v,t))
			{
				img.setPixel(i,j,100,50,200);	
				printf("intersection!\n");
			}
			else
			{
				img.setPixel(i,j,5,5,5);
			}
			/*if(Intersection(&myR, &pt))
			{ 
				color = FindColor(pt, RECURSION_DEPTH);
			}*/
			//I->setPixel(i, j, color.x, color.y, color.z);
			//remainingtime += 1;
			//percentremaining = (remainingtime / totaltime) * 100;
			//system("cls");
			//printf("Progress: %0.3f", percentremaining); 
		}
	}

	img.writeImage();
}

